package net.openvpn.openvpn;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Process;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.concurrent.Semaphore;
import org.apache.http.conn.util.InetAddressUtils;


public class GraphUtils {
    private static String pingError;
    public static String byteTrafficToCount(long l, boolean bl) {
        Double d;
        int n = bl ? 1000 : 1024;
        int n2 = n;
        if (l < (long)n2) {
            StringBuffer stringBuffer = new StringBuffer();
            return stringBuffer.append(l).append(" B/s").toString();
        }
        int n3 = (int)(Math.log((double)l) / Math.log((double)n2));
        StringBuffer stringBuffer = new StringBuffer();
        String string2 = bl ? "kMGTPE" : "KMGTPE";
        StringBuffer stringBuffer2 = stringBuffer.append(string2.charAt(n3 - 1));
        String string3 = bl ? "" : "i";
        String string4 = stringBuffer2.append(string3).toString();
        Object[] arrobject = new Object[2];
        double d2 = (double)l / Math.pow((double)n2, (double)n3);
        arrobject[0] = d = new Double(d2);
        arrobject[1] = string4;
        return String.format((String)"%.1f %sB/s", (Object[])arrobject);
    }

    public static String getIpAddress() {
        try {
            Iterator iterator = ((Collection)Collections.list((Enumeration)NetworkInterface.getNetworkInterfaces())).iterator();
            while (iterator.hasNext()) {
                for (InetAddress inetAddress : (Collection)Collections.list((Enumeration)((NetworkInterface)iterator.next()).getInetAddresses())) {
                    boolean bl;
                    String string2;
                    if (inetAddress.isLoopbackAddress() || !(bl = InetAddressUtils.isIPv4Address((String)(string2 = inetAddress.getHostAddress())))) continue;
                    return string2;
                }
            }
        }
        catch (Exception var0_5) {
            // empty catch block
        }
        return "127.0.0.1";
    }
    public static String getPingHost(String string2) {
        try {
            StringBuffer stringBuffer = new StringBuffer();
            Runtime runtime = Runtime.getRuntime();
            StringBuffer stringBuffer2 = new StringBuffer();
            java.lang.Process process = runtime.exec(stringBuffer2.append("ping -c 1 ").append(string2).toString());
            process.waitFor();
            if (process.exitValue() != 0) return string2;
            InputStreamReader inputStreamReader = new InputStreamReader(process.getInputStream());
            BufferedReader bufferedReader = new BufferedReader((Reader)inputStreamReader);
            do {
                String string3;
                if ((string3 = bufferedReader.readLine()) == null) {
                    return GraphUtils.getPingStats(stringBuffer.toString());
                }
                StringBuffer stringBuffer3 = new StringBuffer();
                stringBuffer.append(stringBuffer3.append(string3).append("\n").toString());
            } while (true);
        }
        catch (IOException | InterruptedException var2_9) {
            return string2;
        }
    }

    public static String getPingStats(String string2) {
        if (string2.contains((CharSequence)"0% packet loss")) {
            int n = string2.indexOf("/mdev = ");
            int n2 = string2.indexOf(" ms\n", n);
            return string2.substring(n + 8, n2).split("/")[2];
        }
        if (string2.contains((CharSequence)"100% packet loss")) {
            pingError = "100% packet loss";
            return pingError;
        }
        if (string2.contains((CharSequence)"% packet loss")) {
            pingError = "partial packet loss";
            return pingError;
        }
        if (string2.contains((CharSequence)"unknown host")) {
            pingError = "Unknown Host";
            return pingError;
        }
        pingError = "Unknown Error";
        return pingError;
	}
}


