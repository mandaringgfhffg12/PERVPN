# OpenVPNLite
for professionals purposes only

Credits:
1. openvpn.net
2. Renzo Lanes Barba
3. and Unknown Developer
4. Alliance Team
5. Raksss

Special Thanks to the fallowing tools 

1. apktool
2. dex2jar
3. DJ Java Decompiler
4. eclipse 
5. Android Studio
6. APK Studio
7. Smali2JavaUI
8. jd-gui 
9. AndroChef Java Decompiler
10. My Brain 

Download Here
https://play.google.com/store/apps/details?id=net.openvpn.openvpn

Website
http://raksss.com/

Facebook 
https://www.facebook.com/profile.php?id=100009354416601

Facebook Page
https://www.facebook.com/groups/raksssdotcom/
