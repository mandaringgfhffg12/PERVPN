เปิดไฟล์ openvpnclient.java

#วางใต้คำ​ import

import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.*;
import android.widget.*;
import android.support.v4.app.*;


_______________________________________________

	
ค้นหาคำนี้ private View username_group;
แล้ววางโค๊ด👇ไว้ใต้คำนี้🖕🖕🖕🖕🖕
	private DrawerLayout drawerLayout;
    private Toolbar toolbar;

_______________________________________________

        
ค้นหาคำนี้👉    setContentView(R.layout.form);
แล้ววางโค็ด👇ใต้คำนี้🖕🖕🖕🖕🖕🖕🖕🖕🖕
		toolbar = (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		initNavigationDrawer();

แล้วเปลี่ยนคำว่า from เป็น  main
_________________________________________________		
 ค้นหาคำนี้👉	 new AppRate(this).setMinDaysUntilPrompt(14).setMinLaunchesUntilPrompt(10).init();
 
    }

แล้ววางโค้ดไว้ใต้

	public void initNavigationDrawer() {
        NavigationView navigationView = (NavigationView)findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
				@Override
				public boolean onNavigationItemSelected(MenuItem menuItem) {

					int id = menuItem.getItemId();

					switch (id){
						case R.id.import_profile:
							request_file_selection_dialog(S_ONSTART_CALLED);
							break;
						case R.id.preferences:
							Intent id1 = new Intent(OpenVPNClient.this,OpenVPNPrefs.class);
							startActivity(id1);
							break;
						case R.id.add_proxy:
							Intent id2 = new Intent(OpenVPNClient.this,OpenVPNAddProxy.class);
							startActivity(id2);
							break;
						case R.id.logout:
							finish();

					}
					drawerLayout.closeDrawers();
					return true;
				}
			});
        View header = navigationView.getHeaderView(0);
        TextView tv_email = (TextView)header.findViewById(R.id.tv_email);
        tv_email.setText("เลือกเมนู");
        drawerLayout = (DrawerLayout)findViewById(R.id.drawer);

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.drawer_open,R.string.drawer_close){

            @Override
            public void onDrawerClosed(View v){
                super.onDrawerClosed(v);
            }

            @Override
            public void onDrawerOpened(View v) {
                super.onDrawerOpened(v);
            }
        };
        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }
		
		
	
__________________________________________________