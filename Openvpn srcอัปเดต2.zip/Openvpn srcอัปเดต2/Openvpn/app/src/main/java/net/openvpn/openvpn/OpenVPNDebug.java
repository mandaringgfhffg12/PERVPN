package net.openvpn.openvpn;

class OpenVPNDebug {
    OpenVPNDebug() {
    }

    public static String pw_repl(String user, String pw) {
        return pw;
    }
}
