package net.openvpn.openvpn;

import android.app.*;
import android.os.*;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;



public class ActivitySpeedTest extends AppCompatActivity 
{
	private LinearLayout adsBanners;
    private Button adsInterestitials;
    private Button adsReward;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speedtest);
		Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("แพ็คเกจอินเตอร์เน็ต");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View pr) {
					onBackPressed();
				}
        
		
		});}}
    


