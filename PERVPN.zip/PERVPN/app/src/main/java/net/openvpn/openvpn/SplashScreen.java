package net.openvpn.openvpn;



import android.content.*;
import android.os.*;
import android.support.v7.app.*;
import android.widget.*;
import android.media.*;
import android.*;
import net.openvpn.openvpn.R;

public class SplashScreen extends AppCompatActivity
{

	private ProgressBar mProgress;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Show the splash screen
		setContentView(R.layout.abc_activity_splash);
		mProgress = (ProgressBar) findViewById(R.id.splash_screen_progress_bar);

		// Start lengthy operation in a background thread
		new Thread(new Runnable() {
				public void run() {
					doWork();
					startApp();
					finish();
				}
			}).start();
	}


	@Override
	protected void onStart()
	{

		super.onStart();
	}

	private void doWork() {
		for (int progress=0; progress<100; progress+=5) {
			try {
				Thread.sleep(300);
				mProgress.setProgress(progress);
			} catch (Exception e) {
				e.printStackTrace();

			}
		}
	}

	private void startApp() {
		Intent intent = new Intent(SplashScreen.this, OpenVPNClient.class);
		startActivity(intent);
	}
}


